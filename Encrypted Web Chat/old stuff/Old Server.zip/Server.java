import java.net.*;
import java.util.Scanner;
import java.io.*;



public class Server {
	private ServerSocket server;
	private Socket client;
	private PrintWriter output;
	private BufferedReader input;
	private Scanner kb;
	private int listenerPort;
	
	public Server() {
		
	}
	
	public void start(int port) throws IOException {
		server = new ServerSocket(port);
		client = server.accept();
		output = new PrintWriter(client.getOutputStream(), true);
		input = new BufferedReader(new InputStreamReader(client.getInputStream()));
		
		String inputLine;
		while ((inputLine = input.readLine()) != null) {
			System.out.println("Message from client: " + inputLine);
			if (inputLine.equals(".")) {
				 System.out.println("Client termination request");
				 output.println("Terminating connection, goodbye");
				 stop();
				 break;
			} else {
				output.println("Your message was: " + inputLine);
			}
		}
	}
	
	
	
	private void stop() throws IOException {
		// TODO Auto-generated method stub
		server.close();
		client.close();
		output.close();
		input.close();
		
		System.out.println("Sockets and streams closed successfully");	
		
	}
	
	public void configure() {
		
	}



	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Server test = new Server();
		
		System.out.println("Server started, please enter port number (over localhost 127.0.0.1)");
		Scanner arg = new Scanner(System.in);
		int port = Integer.parseInt(arg.nextLine());
		System.out.println("You entered: port " + port + " do you wish to continue? y/n");

//		add method for port selection
//		String choice = arg.nextLine();
//		if (choice.equals("y")) {
//			
//		} else {
//			boolean accepted = false;
//			while (!accepted) {
//				System.out.println("please enter port number");
//				
//			}
//		}
		
		arg.close();
		test.start(port);
		
		
		
		
		

	}

}
