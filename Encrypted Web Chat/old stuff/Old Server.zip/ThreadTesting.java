
public class ThreadTesting {

	public Thread createThread() {
		return new ThreadTester();
	}
	
	private class ThreadTester extends Thread{
		public void run() {
			try {
				System.out.println("I am thread number: " + Thread.currentThread().getId());
			} catch (Exception e) {
				System.out.println("Oops");
			}
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThreadTesting t = new ThreadTesting();
		
		for (int i = 0; i < 5; i++) {
			System.out.println(i + " Creating thread...");
			Thread test = t.createThread();
			test.start();
		}
		

	}

}
